Open in Jupyter, Anaconda Navigator

General Flow in Notebook:

1. Title & Objective
2. Data Overview and view
3. Data Cleaning
4. Exploratory Analysis
5. Funnel Analysis and Bar/Line Graphs
6. Prediction (ML - Regression/ may also use Holt)